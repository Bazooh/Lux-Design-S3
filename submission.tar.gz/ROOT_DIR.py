#ROOT_DIR = "/home/hadriencrs/Code/python/Lux-Design-S3/"
ROOT_DIR = "/kaggle_simulations/agent/"