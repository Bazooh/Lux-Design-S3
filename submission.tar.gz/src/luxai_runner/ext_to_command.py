ext_to_command = {
    ".js": "node",
    ".py": "python3",
    ".out": "./",
    ".exe": "./",
    ".java": "java",
}
